# The Come Up — Secure Upload Starter

This folder adds a **secure, client‑side encrypted upload** flow to your repo using:
- **WebCrypto AES‑GCM** in the browser (end‑to‑end encryption)
- **AWS S3 presigned PUT URL** (short‑lived)
- **SSE‑KMS** enforced at rest on S3 objects

## Structure
- `server/` — minimal Express API that mints presigned PUT URLs (SSE‑KMS required)
- `web/` — a simple static page that encrypts and uploads ciphertext

## Quick Start
1. Create `.env` from `.env.example` and fill AWS values.
2. Set S3 bucket CORS to allow `PUT` from your domain.
3. Install & run server:
   ```bash
   cd server
   npm i
   npm start
   ```
4. Serve the static page (any static server):
   ```bash
   # from repo root
   python3 -m http.server --directory web 8080
   # open http://localhost:8080
   ```

## Security Notes
- Keep presigned URL expiry **short** (60–120s).
- Enforce `SSE-KMS` in the signature (already done).
- Add authentication to `/api/presign` so only logged-in users can upload.
- Validate filename/size/MIME before presigning; add lifecycle rules to auto-delete.
- For large files use multipart upload + chunked encryption (libsodium secretstream or per-chunk AES‑GCM).
