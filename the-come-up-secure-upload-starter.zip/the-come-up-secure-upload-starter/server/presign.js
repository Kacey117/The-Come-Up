import "dotenv/config";
import express from "express";
import crypto from "node:crypto";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const app = express();
app.use(express.json());

// Read required env vars
const {
  AWS_REGION,
  S3_BUCKET,
  KMS_KEY_ID
} = process.env;

if (!AWS_REGION || !S3_BUCKET || !KMS_KEY_ID) {
  console.warn("[WARN] Missing one of AWS_REGION, S3_BUCKET, KMS_KEY_ID in environment.");
}

const s3 = new S3Client({ region: AWS_REGION });

// TODO: plug your auth middleware here to restrict who can call this
app.post("/api/presign", async (req, res) => {
  try {
    const { filename } = req.body || {};
    if (!filename) {
      return res.status(400).json({ error: "filename required" });
    }

    // Basic sanitize of filename (you can do more strict rules)
    const safeName = String(filename).replace(/[^\w.\-]/g, "_");
    const objectKey = `secure-uploads/${crypto.randomUUID()}-${safeName}`;

    const command = new PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: objectKey,
      ContentType: "application/octet-stream",
      // Enforce encryption at rest with your KMS key
      ServerSideEncryption: "aws:kms",
      SSEKMSKeyId: KMS_KEY_ID
    });

    // Short expiry (60 seconds). Keep it tight.
    const url = await getSignedUrl(s3, command, { expiresIn: 60 });

    return res.json({
      url,
      objectKey,
      headers: {
        "Content-Type": "application/octet-stream",
        "x-amz-server-side-encryption": "aws:kms",
        "x-amz-server-side-encryption-aws-kms-key-id": KMS_KEY_ID
      }
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Failed to create presigned URL" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Presigner listening on :${PORT}`));
